class Heroimage extends HTMLElement {
  constructor() {
    super();
    this.render();
  }

  render() {
    this.innerHTML = `
    <div class="herobanner">      
    <picture>
    <source media="(max-width: 600px)" srcset="/images/heros/hero-image_1-small.jpg">
    <img src='/images/heros/hero-image_1-large.jpg' 
         alt="Large Image For Restaurant">
    </picture>
    </div>
  `;
  }
}
customElements.define('hero-image', Heroimage);
