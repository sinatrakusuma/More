import HomePage from '../views/pages/home/homepage';
import DetailPage from '../views/pages/detail/detailpage';
import PageFavorite from '../views/pages/favorite/pagefavorite';

const routes = {
  '/': HomePage,
  '/favorite': PageFavorite,
  '/detail/:id': DetailPage,
  '*': 'NotFound',
};

export default routes;
