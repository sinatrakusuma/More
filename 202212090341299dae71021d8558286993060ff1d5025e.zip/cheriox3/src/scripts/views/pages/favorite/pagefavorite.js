import CherioDataIDB from '../../../data/idb/cherio-idb';
import cardComponent from '../../templates/card-component';

const PageFavorite = {
  async render() {
    return `
        <div class="cardContainer cardContainer-pagefavorite"></div>
      `;
  },
  async afterRender() {
    const restaurants = await CherioDataIDB.getAllRestaurants();
    const restaurantList = document.querySelector('.cardContainer');
    restaurants.forEach((item) => {
      console.log(item);
      restaurantList.insertAdjacentHTML('beforeend', cardComponent(item));
    });
  },
};

export default PageFavorite;
