import 'regenerator-runtime';
import '../styles/main.css';
import switcherRegister from './utils/switch/switcherregister';
import App from './views/app';

import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';

const skipToContent = document.querySelector('.next-to-content');
skipToContent.addEventListener('click', () => {
  document.querySelector('#content').scrollIntoView({ behavior: 'smooth' });
  skipToContent.blur();
});
const app = new App({
  button: document.querySelector('.menu'),
  drawer: document.querySelector('.navbar'),
  content: document.querySelector('#content'),
});
window.addEventListener('hashchange', () => {
  app.renderPage();
});
window.addEventListener('load', () => {
  app.renderPage();
  switcherRegister();
});
