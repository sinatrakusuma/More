Feature("Liking Resto");
Before(({ I }) => {
  I.amOnPage("/");
});
Scenario("Melakukan Proses Menyukai Restaurant", ({ I }) => {
  I.seeElement(".carding-link-button");

  const firsResto = locate(".carding-link-button").first();
  I.click(firsResto);
  I.click("#likeButton");
  I.amOnPage("/#/favorite");
  I.seeElement(".carding-link-button");
});
//tidakmenyukairesto
Scenario("Melakukan Tidak Menyukai  Restaurant", ({ I }) => {
  I.seeElement(".carding-link-button");
  const firsResto = locate(".carding-link-button").first();
  I.click(firsResto);
  I.seeElement("#likeButton");
  I.click("#likeButton");
  I.amOnPage("/#/favorite");
  I.seeElement(".carding-link-button");
  const firstRestoLike = locate(".carding-link-button").first();
  I.click(firstRestoLike);
  I.seeElement("#likeButton");
  I.click("#likeButton");
  I.amOnPage("/#/favorite");
  I.dontSeeElement(".carding-link-button");
});