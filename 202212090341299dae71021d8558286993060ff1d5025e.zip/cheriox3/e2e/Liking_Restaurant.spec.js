Feature("Liking Resto");
Before(({ I }) => {
  I.amOnPage("/");
});
Scenario('Menyukai salah satu restaurant dan membatalkannya', async ({ I }) => {
  I.amOnPage('/');
  I.wait(2);
  I.seeElement('.carding-link-button');
  await I.grabTextFrom(locate('.carding-link-button').first());
  I.click(locate('.carding-link-button').first());
  I.wait(2);
  I.click('#likeButton');
  I.amOnPage('/#/favorite');
  I.click(locate('.carding-link-button').first());
  I.wait(2);

  I.seeElement('#likeButton');
  I.click('#likeButton');
  I.amOnPage('/#/favorite');
  I.dontSeeElement('.carding-link-button');
});
