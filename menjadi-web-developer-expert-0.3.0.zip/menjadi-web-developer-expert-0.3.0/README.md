# 📃 Description

Projek ini adalah submission dari Dicoding untuk kelas Menjadi Web Developer Expert. Kelas ini memiliki 1 submission yang harus diselesaikan untuk mendapatkan sertifikat.

> Submission 1 diharuskan untuk tidak menggunakan framework CSS apapaun.
