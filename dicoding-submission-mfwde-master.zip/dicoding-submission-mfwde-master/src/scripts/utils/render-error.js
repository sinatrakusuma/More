import swal from 'sweetalert';

const RenderError = (message) => swal('Error!', message, 'error');

export default RenderError;
