# dicoding-submission-mfwde

Dicoding Submission Menjadi Front-End Web Developer Expert

## Screenshoot

![main](screenshoot/foodoso.gif)
![main](screenshoot/submission-info-1.png)
![main](screenshoot/submission-info-2.png)
